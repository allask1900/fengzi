
select getdate()

/**2014-01-14 21:28:38.323
CREATE NONCLUSTERED INDEX [IX_TB_SEARCH_Product_IsValid] ON [dbo].[TB_SEARCH_Product] 
(
	[IsValid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
**/

/**2014-01-07 14:48:26.013
CREATE PROCEDURE dbo.PR_Common_BackupDB
    @filePath varchar(500)
as  
    backup database SearchSystem to disk = @filePath
**/
    
    
/**2014-01-05 22:18:39.810
TB_SEARCH_Site������status�ֶ� 
ALTER TABLE [dbo].[TB_SEARCH_Site] ADD Status tinyint not null DEFAULT ((0))
**/


/**2014-01-02 10:53:02.713
CREATE NONCLUSTERED INDEX [IX_TB_SEARCH_Product_IsValid] ON [dbo].[TB_SEARCH_Product] 
(
	[IsValid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
**/



/**
ALTER TABLE [dbo].[TB_SEARCH_Product] DROP CONSTRAINT DF_TB_SEARCH_Product_ShopCount
ALTER TABLE [dbo].[TB_SEARCH_Product] DROP COLUMN ShopCount

ALTER TABLE [dbo].[TB_SEARCH_Product] DROP CONSTRAINT DF_TB_SEARCH_Product_MinPrice
ALTER TABLE [dbo].[TB_SEARCH_Product] DROP COLUMN MinPrice

ALTER TABLE [dbo].[TB_SEARCH_Product] DROP CONSTRAINT DF_TB_SEARCH_Product_MaxPrice
ALTER TABLE [dbo].[TB_SEARCH_Product] DROP COLUMN MaxPrice
**/

/**2013-12-28 15:39:50.880
ALTER TABLE [dbo].[TB_SEARCH_Product] DROP CONSTRAINT [DF_TB_SEARCH_Product_IsValid]
go
alter table tb_search_product ALTER COLUMN IsValid tinyint not null
go
ALTER TABLE [dbo].[TB_SEARCH_Product] ADD  CONSTRAINT [DF_TB_SEARCH_Product_IsValid]  DEFAULT ((0)) FOR [IsValid]
go
**/