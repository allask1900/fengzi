use SearchSystem 
select count(*) from TB_SEARCH_SiteCategory where SiteID=500
select * from TB_SEARCH_SiteCategory where SiteID=808 and CategoryID like '17%' order by CategoryID desc

select * from TB_SEARCH_Category  where ProductCount>0

select  count(*) from TB_SEARCH_ProductList with(nolock) where siteid=30


select  top 10 * from TB_SEARCH_ProductList where LEN(categoryids)>10  

select top 1000 * from tb_search_hotword


select * from tb_search_category where categoryname like '%VoIP%' and Isvalid=1

select * from tb_search_category where categoryid like '29%' order by categoryid


select * from TB_SEARCH_SiteConfig